# @surgecredit/auction-sdk

Headless TypeScript SDK for **Surge Credit liquidation auctions** on Base. Discover
Dutch auctions of BTC collateral, quote profitability against the on-chain oracle,
buy collateral with USDC, and open auctions on unhealthy positions. Bring your own
viem clients; the SDK never holds keys.

Both roles are permissionless by protocol design. Anyone may call `checkHealth` to
open a liquidation auction on an unhealthy position, and anyone may call `buy` to
clear one.

## How liquidation works on Surge

Every position is a BTC-collateralized, USDC-denominated credit line, identified by an NFT id.

1. When a position's collateral ratio falls below its market's liquidation
   threshold, `checkHealth(nftId)` opens a Dutch auction. The opening price is the
   live debt plus the liquidation penalty. The collateral for sale is fixed at open
   time, so a lower clearing price buys the same BTC for less USDC.
2. The price steps down toward a floor until the auction expires. The SDK never
   assumes curve parameters; it always reads `getCurrentPrice(nftId)`.
3. `buy(nftId, btcAddress)` pays the current price in USDC, retires the debt, and
   records the buyer's BTC address as the collateral recipient.

BTC delivery is off-chain and not atomic. After `buy`, the protocol's signer
network signs and broadcasts a Bitcoin transaction to your address, and delivery is
confirmed on-chain afterward. You pay USDC at purchase time and receive BTC minutes
to hours later. This is a trust assumption on the protocol operator, so size your
exposure to it.

## Install

This package is private on npm. You need a read token for the `@surgecredit` scope
before npm can resolve it. Ask the Surge team for one.

Create a `.npmrc` in your project root and git-ignore it:

```
@surgecredit:registry=https://registry.npmjs.org/
//registry.npmjs.org/:_authToken=${NPM_TOKEN}
```

npm resolves `${NPM_TOKEN}` from the environment at install time, so the token never
lands in a file you might commit. Export it in your shell profile, or add it as a
masked secret in CI:

```bash
export NPM_TOKEN=<your-read-token>
npm install @surgecredit/auction-sdk viem
```

`viem` (>= 2.49.4) is a peer dependency, so install it explicitly.

If the token is missing, expired, or scoped to the wrong packages, npm reports a
`404 Not Found` rather than an auth error. That is deliberate on npm's side: it
avoids revealing whether a private package exists. Treat a sudden 404 on a package
that installed yesterday as an auth problem, not a missing version.

## Quick start

```ts
import { createWalletClient, custom } from "viem";
import { base } from "viem/chains";
import { SurgeAuctionClient, createSurgeAuctionPublicClient } from "@surgecredit/auction-sdk";

const publicClient = createSurgeAuctionPublicClient("https://mainnet.base.org", base);
const walletClient = createWalletClient({ chain: base, transport: custom(window.ethereum) });

const auctions = new SurgeAuctionClient({
  publicClient,
  walletClient,   // omit for a read-only client
  network: "mainnet", // "signet" = Base Sepolia
});

for (const a of await auctions.listAuctions()) {
  const quote = await auctions.quoteBuy(a.nftId, { estBtcDeliveryFeeUsd: 3, targetMarginBps: 300 });
  console.log(a.nftId, quote.priceUsdc, quote.netProfitUsd, quote.profitable);
}
```

The constructor checks that `publicClient` is on the configured chain, so a mainnet
config over a testnet RPC fails fast instead of reading a wrong address.

## Reads

```ts
await auctions.listAuctions();          // AuctionSnapshot[], buyable only by default
await auctions.getAuction(nftId);       // AuctionInfo | null
await auctions.getCurrentPrice(nftId);  // { raw, usdc }
await auctions.getOracleBtcPriceUsd();  // BTC/USD from the protocol oracle
await auctions.quoteBuy(nftId, opts);   // BuyQuote: profitability at current price
await auctions.isLiquidatable(nftId);   // mirrors the contract health test
await auctions.getUsdcBalance(owner);
await auctions.getAllowance(owner);     // raw USDC allowance to the AuctionHouse
```

`listAuctions` discovers auctions from `LogAuctionCreated` events and returns each
with its current price. By default it returns only auctions that are buyable right
now (active, unexpired, unwon). Pass `{ onlyBuyable: false }` to include all, and
`{ lookbackBlocks }` to widen the event scan.

## Quote profitability

`quoteBuy` values the collateral at the oracle BTC price and applies your margin
gate. With no options, `profitable` just means the price is below collateral value.

```ts
const q = await auctions.quoteBuy(nftId, {
  estBtcDeliveryFeeUsd: 3, // assumed BTC miner fee per delivery
  targetMarginBps: 300,    // require 3% of collateral value as net profit
});
// q.collateralValueUsd, q.priceUsdc, q.netProfitUsd, q.requiredProfitUsd, q.profitable
```

The same math lives in the exported pure `computeBuyEconomics` helper if you want to
score off your own data.

## Buy

```ts
const address = "0xBuyerWallet";

// Approve USDC to the AuctionHouse once (exact amount, or omit for unlimited).
await auctions.approveUsdc({ account: address, amountUsdc: "50", waitForReceipt: true });

// Buy at the current price; seized BTC is sent to your Bitcoin address.
await auctions.buy({
  nftId,
  btcAddress: "bc1q...",
  account: address,
  waitForReceipt: true,
});
```

`buy` pre-flights the auction state, your USDC balance and allowance, and validates
the BTC address for the network, throwing a typed `SurgeAuctionError` instead of
letting the transaction revert. A wrong-network BTC address is rejected up front
because seized BTC sent to it would be unspendable.

## Open an auction (keeper)

```ts
if (await auctions.isLiquidatable(nftId)) {
  await auctions.checkHealth({ nftId, account: address, waitForReceipt: true });
}
```

`checkHealth` is permissionless. It pre-checks that the position is actually
liquidatable so you do not spend gas on a no-op. Pass `skipPreflight: true` to send
it unconditionally.

## Errors

Every error the SDK raises is a `SurgeAuctionError` with a stable `.code`:

```ts
import { SurgeAuctionError } from "@surgecredit/auction-sdk";

try {
  await auctions.buy({ nftId, btcAddress });
} catch (err) {
  if (err instanceof SurgeAuctionError && err.code === "AUCTION_ALREADY_WON") {
    // someone else cleared it first
  }
}
```

Codes: `WALLET_REQUIRED`, `ACCOUNT_UNRESOLVED`, `WRONG_CHAIN`, `INVALID_AMOUNT`,
`INVALID_BTC_ADDRESS`, `AUCTION_NOT_FOUND`, `AUCTION_INACTIVE`, `AUCTION_EXPIRED`,
`AUCTION_ALREADY_WON`, `INSUFFICIENT_USDC_BALANCE`, `ALLOWANCE_REQUIRED`,
`NOT_LIQUIDATABLE`.

## Networks

| network | chain | chainId | AuctionHouse |
| --- | --- | --- | --- |
| `mainnet` | Base | `8453` | `0xE5Ff1E177dDE3FC33f5457855b14e6bD3B0C6566` |
| `signet` | Base Sepolia | `84532` | `0xf5Ea942ee2C36B729B107011F034fF4b52dB41ce` |

For advanced setups you can pass a full `config` object instead of `network`.

## Economics and safety

- Bid math is not a safety boundary. The chain settles the trade and enforces every
  cap, so a stale pre-flight read means at worst a revert, never a loss.
- For dust positions the margin is thin and every win needs its own BTC delivery
  with its own fee, so tune `targetMarginBps` and `estBtcDeliveryFeeUsd` to skip
  unprofitable auctions.
- Use a fresh, dedicated wallet funded only with working capital and gas. Approve
  the exact amount you plan to spend rather than an unlimited allowance.

## Develop

```bash
npm install
npm run typecheck
npm test
npm run build
```

## Related

For an end-to-end keeper you can deploy, see the reference `surge-liquidation-bot`,
which wraps the same contract calls with polling, spend caps, and systemd packaging.
